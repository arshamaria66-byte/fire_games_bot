
import logging
from telegram import (
    InlineKeyboardButton, InlineKeyboardMarkup, Update, ReplyKeyboardRemove
)
from telegram.ext import (
    ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
)

# فعال سازی لاگ برای دیباگ
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)

# --- تنظیمات پایه ---
TOKEN = "YOUR_BOT_TOKEN"  # توکن ربات از BotFather
ADMIN_ID = "@FireGamesAdmin"

# --- پیام خوش‌آمد ---
WELCOME_MSG = (
    "🔥 به ربات سفارش فایر گیمز خوش آمدید 🔥
"
    "می‌توانید همین الان روی دکمه‌ی زیر بزنید و خریدتان را ثبت کنید..."
)

# --- دکمه‌های منوی اصلی ---
def main_menu():
    buttons = [
        [InlineKeyboardButton("🛒 ثبت سفارش", callback_data="order")],
        [InlineKeyboardButton("💰 استعلام قیمت", callback_data="price")],
        [InlineKeyboardButton("📦 پیگیری سفارش", callback_data="track")]
    ]
    return InlineKeyboardMarkup(buttons)

# --- دکمه‌های ظرفیت ---
def capacity_menu(next_step):
    buttons = [
        [InlineKeyboardButton("ظرفیت 1", callback_data=f"{next_step}:cap1")],
        [InlineKeyboardButton("ظرفیت 2", callback_data=f"{next_step}:cap2")],
        [InlineKeyboardButton("ظرفیت 3", callback_data=f"{next_step}:cap3")],
        [InlineKeyboardButton("ظرفیت کامل", callback_data=f"{next_step}:full")]
    ]
    return InlineKeyboardMarkup(buttons)

# --- دکمه‌های ریجن ---
def region_menu(next_step):
    buttons = [
        [InlineKeyboardButton("🇺🇸 آمریکا", callback_data=f"{next_step}:us")],
        [InlineKeyboardButton("🇮🇳 هند", callback_data=f"{next_step}:in")],
        [InlineKeyboardButton("🇹🇷 ترکیه", callback_data=f"{next_step}:tr")],
        [InlineKeyboardButton("🌍 سایر کشورها", callback_data=f"{next_step}:other")]
    ]
    return InlineKeyboardMarkup(buttons)

# --- شروع ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message:
        await update.message.reply_text(WELCOME_MSG, reply_markup=main_menu())

# --- هندلر کلیک دکمه --
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data

    # ثبت سفارش
    if data == "order":
        await query.edit_message_text("ظرفیت خود را انتخاب کنید:", reply_markup=capacity_menu("order_region"))
    elif data.startswith("order_region"):
        await query.edit_message_text("ریجن یا منطقه‌ی خود را انتخاب کنید:", reply_markup=region_menu("order_game"))
    elif data.startswith("order_game"):
        await query.edit_message_text("بازی مد نظر خود را انتخاب کنید: 
(بزودی اضافه می‌شود)")

    # استعلام قیمت
    elif data == "price":
        await query.edit_message_text("ظرفیت خود را انتخاب کنید:", reply_markup=capacity_menu("price_region"))
    elif data.startswith("price_region"):
        await query.edit_message_text("ریجن خود را انتخاب کنید:", reply_markup=region_menu("price_game"))
    elif data.startswith("price_game"):
        await query.edit_message_text("بازی مد نظر خود را انتخاب کنید: 
(بزودی اضافه می‌شود)")

    # پیگیری سفارش
    elif data == "track":
        await query.edit_message_text(f"برای پیگیری سفارش، به ادمین مراجعه کنید: {ADMIN_ID}")

# --- اجرای اپ ---
if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.run_polling()
